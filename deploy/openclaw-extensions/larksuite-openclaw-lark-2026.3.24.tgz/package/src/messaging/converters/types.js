"use strict";
/**
 * Copyright (c) 2026 ByteDance Ltd. and/or its affiliates
 * SPDX-License-Identifier: MIT
 *
 * Shared types for the content converter system.
 */
Object.defineProperty(exports, "__esModule", { value: true });
