#!/bin/bash

echo "$(date) Start..."

[ -z "${SERVICE}" ] && exit 1
[ -z "${DOMAIN}" ] && exit 1
[ -z "${REDIS_PORT}" ] && exit 1
[ -z "${SENTINEL_PORT}" ] && exit 1
[ -z "${MASTER_GROUP}" ] && exit 1
[ -z "${QUORUM}" ] && exit 1
[ -z "${SET_DEFAULT_USER}" ] && exit 1
[ -z "${ROOT_USER}" ] && exit 1
[ -z "${ROOT_PASS_ENCODE}" ] && exit 1
[ -z "${MONITOR_USER}" ] && exit 1
[ -z "${MONITOR_PASS_ENCODE}" ] && exit 1
[ -z "${SENTINEL_USER}" ] && exit 1
[ -z "${SENTINEL_PASS_ENCODE}" ] && exit 1

ROOT_PASS=$(echo -n "${ROOT_PASS_ENCODE}" | base64 -d | awk '{ print $1 }')
MONITOR_PASS=$(echo -n "${MONITOR_PASS_ENCODE}" | base64 -d | awk '{ print $1 }')
SENTINEL_PASS=$(echo -n "${SENTINEL_PASS_ENCODE}" | base64 -d | awk '{ print $1 }')

HOSTNAME="$(hostname)"
INDEX="${HOSTNAME##*-}"

REDIS_CONF="/data/conf/redis.conf"
SENTINEL_CONF="/data/conf/sentinel.conf"
USERS_ACL="/data/conf/users.acl"
SENTINEL_ACL="/data/conf/sentinel-users.acl"
MASTER=""

set -eu

sentinel_get_master() {
set +e
    redis-cli -h ${SERVICE} -p ${SENTINEL_PORT} --user ${SENTINEL_USER} --pass ${SENTINEL_PASS} --no-auth-warning --raw \
        sentinel get-master-addr-by-name "${MASTER_GROUP}" | grep -v "${REDIS_PORT}"
set -e
}

sentinel_get_master_retry() {
    master=""
    retry=${1}
    sleep=3
    for i in $(seq 1 "${retry}"); do
        master=$(sentinel_get_master)
        if [ -n "${master}" ]; then
            break
        fi
        sleep $((sleep + i))
    done
    echo "${master}"
}

identify_master() {
    MASTER="$(sentinel_get_master_retry 3)"
}

sentinel_update() {
    MY_SENTINEL_ID=$( echo -n "${SERVICE}-${INDEX}" | sha256sum | cut -c1-40 )
    echo "sentinel myid ${MY_SENTINEL_ID}" >> "${SENTINEL_CONF}"
    echo "sentinel monitor ${MASTER_GROUP} ${1} ${REDIS_PORT} ${QUORUM}" >> "${SENTINEL_CONF}"
    echo "sentinel announce-ip ${ANNOUNCE_IP}" >> "${SENTINEL_CONF}"
    echo "sentinel announce-port ${SENTINEL_PORT}" >> "${SENTINEL_CONF}"
}

redis_update() {
    echo "replicaof ${1} ${REDIS_PORT}" >> "${REDIS_CONF}"
    echo "replica-announce-ip ${ANNOUNCE_IP}" >> "${REDIS_CONF}"
    echo "replica-announce-port ${REDIS_PORT}" >> "${REDIS_CONF}"
}

copy_config() {
    cp /readonly-config/redis.conf "${REDIS_CONF}"
    cp /readonly-config/sentinel.conf "${SENTINEL_CONF}"

    ROOT_PASS_SHA256=$(echo -n "${ROOT_PASS}" | sha256sum | awk '{ print $1 }')
    MONITOR_PASS_SHA256=$(echo -n "${MONITOR_PASS}" | sha256sum | awk '{ print $1 }')
    SENTINEL_PASS_SHA256=$(echo -n "${SENTINEL_PASS}" | sha256sum | awk '{ print $1 }')

    if [ ! -f "${USERS_ACL}" ]; then
        cp /readonly-config/users.acl "${USERS_ACL}"
        if [ "$SET_DEFAULT_USER" = "true" ]; then
            echo "user default on #${ROOT_PASS_SHA256} ~* +@all allchannels" >> "${USERS_ACL}"
        else
            echo "user default off #${ROOT_PASS_SHA256} ~* +@all allchannels" >> "${USERS_ACL}"
        fi
        echo "user ${ROOT_USER} on #${ROOT_PASS_SHA256} ~* +@all allchannels" >> "${USERS_ACL}"
        echo "user sentinel-user on #${SENTINEL_PASS_SHA256} allchannels +multi +slaveof +ping +exec +subscribe +config|rewrite +role +publish +info +client|setname +client|kill +script|kill" >> "${USERS_ACL}"
        echo "user replica-user on #${SENTINEL_PASS_SHA256} +psync +replconf +ping" >> "${USERS_ACL}"
    else
        if [ "$SET_DEFAULT_USER" = "true" ]; then
            sed -i "s/^user default .*/user default on #${ROOT_PASS_SHA256} ~* +@all allchannels/" "${USERS_ACL}"
        else
            sed -i "s/^user default .*/user default off #${ROOT_PASS_SHA256} ~* +@all allchannels/" "${USERS_ACL}"
        fi
        sed -i "s/^user ${ROOT_USER} .*/user ${ROOT_USER} on #${ROOT_PASS_SHA256} ~* +@all allchannels/" "${USERS_ACL}"
        sed -i "s/^user sentinel-user .*/user sentinel-user on #${SENTINEL_PASS_SHA256} allchannels +multi +slaveof +ping +exec +subscribe +config|rewrite +role +publish +info +client|setname +client|kill +script|kill/" "${USERS_ACL}"
    fi
    sed -i "s/^user ${MONITOR_USER} .*/user ${MONITOR_USER} on #${MONITOR_PASS_SHA256} -@all +ping +@connection +memory -readonly +strlen +config|get +xinfo +pfcount -quit +zcard +type +xlen -readwrite -command +client -wait +scard +llen +hlen +get +eval +slowlog +cluster|info +cluster|slots +cluster|nodes -hello -echo +info +latency +scan -reset -auth -asking/" "${USERS_ACL}"

    if [ ! -f "${SENTINEL_ACL}" ]; then
        cp /readonly-config/sentinel-users.acl "${SENTINEL_ACL}"
        if [ "$SET_DEFAULT_USER" = "true" ]; then
            echo "user default on #${ROOT_PASS_SHA256} ~* +@all allchannels" >> "${SENTINEL_ACL}"
        else
            echo "user default off #${ROOT_PASS_SHA256} ~* +@all allchannels" >> "${SENTINEL_ACL}"
        fi
        echo "user ${ROOT_USER} on #${ROOT_PASS_SHA256} ~* +@all allchannels" >> "${SENTINEL_ACL}"
        echo "user sentinel-user on #${SENTINEL_PASS_SHA256} -@all +auth +client|getname +client|id +client|setname +command +hello +ping +role +sentinel|get-master-addr-by-name +sentinel|master +sentinel|myid +sentinel|replicas +sentinel|sentinels +sentinel|masters" >> "${SENTINEL_ACL}"
    else
        if [ "$SET_DEFAULT_USER" = "true" ]; then
            sed -i "s/^user default .*/user default on #${ROOT_PASS_SHA256} ~* +@all allchannels/" "${SENTINEL_ACL}"
        else
            sed -i "s/^user default .*/user default off #${ROOT_PASS_SHA256} ~* +@all allchannels/" "${SENTINEL_ACL}"
        fi
        sed -i "s/^user ${ROOT_USER} .*/user ${ROOT_USER} on #${ROOT_PASS_SHA256} ~* +@all allchannels/" "${SENTINEL_ACL}"
        sed -i "s/^user sentinel-user .*/user sentinel-user on #${SENTINEL_PASS_SHA256} -@all +auth +client|getname +client|id +client|setname +command +hello +ping +role +sentinel|get-master-addr-by-name +sentinel|master +sentinel|myid +sentinel|replicas +sentinel|sentinels +sentinel|masters/" "${SENTINEL_ACL}"
    fi
    sed -i "s/^user ${MONITOR_USER} .*/user ${MONITOR_USER} on #${MONITOR_PASS_SHA256} -@all +ping +@connection -command +client -hello +info -auth +sentinel|masters +sentinel|replicas +sentinel|slaves +sentinel|sentinels +sentinel|ckquorum +sentinel|failover +sentinel|get-master-addr-by-name/" "${SENTINEL_ACL}"
}

setup_defaults() {
    if [ "${INDEX}" = "0" ]; then
        redis_update "${ANNOUNCE_IP}"
        sentinel_update "${ANNOUNCE_IP}"
        sed -i "s/^.*replicaof.*//" "${REDIS_CONF}"
    else
        DEFAULT_MASTER="${SERVICE}-announce-0.${DOMAIN}"
        redis_update "${DEFAULT_MASTER}"
        sentinel_update "${DEFAULT_MASTER}"
    fi
}

redis_ping() {
set +e
    redis_cli_args="-h ${MASTER} -p ${REDIS_PORT} --user ${MONITOR_USER} --pass ${MONITOR_PASS} --no-auth-warning"
    redis-cli ${redis_cli_args} ping
set -e
}

redis_ping_retry() {
    ping=""
    retry=${1}
    sleep=3
    for i in $(seq 1 "${retry}"); do
        if [ "$(redis_ping)" = "PONG" ]; then
            ping="PONG"
            break
        fi
        sleep $((sleep + i))
        MASTER=$(sentinel_get_master)
    done
    echo "${ping}"
}

find_master() {
    if [ "$(redis_ping_retry 3)" != "PONG" ]; then
        redis_cli_args="${SERVICE} -p ${SENTINEL_PORT} --user ${SENTINEL_USER} --pass ${SENTINEL_PASS} --no-auth-warning --raw"
        if redis-cli ${redis_cli_args} sentinel failover "${MASTER_GROUP}" | grep -q "NOGOODSLAVE" ; then
            setup_defaults
            return 0
        fi
        sleep 10
        MASTER="$(sentinel_get_master)"
        if [ "${MASTER}" ]; then
            redis_update "${MASTER}"
            sentinel_update "${MASTER}"
            if [ "${MASTER}" = "${ANNOUNCE_IP}" ]; then
                sed -i "s/^.*replicaof.*//" "${REDIS_CONF}"
            fi
        else
            exit 1
        fi
    else
        redis_update "${MASTER}"
        sentinel_update "${MASTER}"
    fi
}

check_aof() {
    AOF_DIR="/data/appendonlydir"
    if [ -d "${AOF_DIR}" ]; then
        for aof in "${AOF_DIR}"/*.aof; do
            [ -e "${aof}" ] || continue
            if ! redis-check-aof "${aof}" >/dev/null 2>&1; then
                cp "${aof}" "${aof}.bak.$(date +%s)"
                echo "y" | redis-check-aof --fix "${aof}"
            fi
        done
    fi
}

mkdir -p /data/conf/
copy_config
identify_master
ANNOUNCE_IP="${SERVICE}-announce-${INDEX}.${DOMAIN}"
if [ "${MASTER}" ]; then
    find_master
else
    setup_defaults
fi
check_aof
echo "$(date) Ready..."
